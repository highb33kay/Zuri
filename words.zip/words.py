user_input = "hello daddy"
print(len(user_input.split(" ")))